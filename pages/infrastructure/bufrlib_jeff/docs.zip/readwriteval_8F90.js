var readwriteval_8F90 =
[
    [ "drfini", "readwriteval_8F90.html#a8a84d615371869d93f16c8617575dee2", null ],
    [ "getvalnb", "readwriteval_8F90.html#a10cd831e6dc0a773534c5c2787da56c8", null ],
    [ "hold4wlc", "readwriteval_8F90.html#a551fbe590397eacf06bb471b738dd6a5", null ],
    [ "readlc", "readwriteval_8F90.html#aad0d9cae550b97bc950c739ff44ca6b2", null ],
    [ "setvalnb", "readwriteval_8F90.html#ac8bbcb32a65a5acdf50e0f5d835c6ac2", null ],
    [ "ufbint", "readwriteval_8F90.html#a6eb38e7aa610c36787b90e50b290eea7", null ],
    [ "ufbrep", "readwriteval_8F90.html#af46dec3ef4cc6f467323b40eb14a4024", null ],
    [ "ufbrp", "readwriteval_8F90.html#a3f676e2267d902f8bc913a6d9d1a6aac", null ],
    [ "ufbrw", "readwriteval_8F90.html#a543d19ccf3a36ded022cbbe8db66ee85", null ],
    [ "ufbseq", "readwriteval_8F90.html#a4895b24addb0b3e23f5bd92fd891656e", null ],
    [ "ufbsp", "readwriteval_8F90.html#a7281bf7fbd6efa3a9be946f7d63cffad", null ],
    [ "ufbstp", "readwriteval_8F90.html#a921e4820b81e9f33e28a0d0452785a14", null ],
    [ "writlc", "readwriteval_8F90.html#aecfa08f631e1af46b472c007b93b2955", null ]
];