var bfrini_8F90 =
[
    [ "bfrini", "bfrini_8F90.html#ab3f045cc170403305543e34e30b87001", null ]
];