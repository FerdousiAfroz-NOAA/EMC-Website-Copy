var openclosebf_8F90 =
[
    [ "closbf", "openclosebf_8F90.html#a48a49bb82348400c1ba6af00c0138ab3", null ],
    [ "fortran_close", "openclosebf_8F90.html#aa585324fae3ecf559d6f39507dde6715", null ],
    [ "fortran_open", "openclosebf_8F90.html#a80df0d62e629b094edd2b3682a7d9e3a", null ],
    [ "openbf", "openclosebf_8F90.html#a9dc7e4fb476a5528a958ee132ee6392d", null ],
    [ "posapx", "openclosebf_8F90.html#aeef6f5d08d9631dbe92c1821a9d02903", null ],
    [ "status", "openclosebf_8F90.html#abceda08f9c29378d3ddadeb46e823d00", null ],
    [ "ufbcnt", "openclosebf_8F90.html#aac1b87fbbb688e4f5e2120012eaee382", null ],
    [ "wtstat", "openclosebf_8F90.html#ada4363a068f7df043d75b4519c55142f", null ]
];