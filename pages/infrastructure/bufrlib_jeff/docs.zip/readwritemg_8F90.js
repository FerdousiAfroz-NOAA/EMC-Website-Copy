var readwritemg_8F90 =
[
    [ "closmg", "readwritemg_8F90.html#a63b37b74d9833df9d99e3937a2fa293a", null ],
    [ "cnved4", "readwritemg_8F90.html#adc65969dd9c1cedbab0425827e241963", null ],
    [ "getlens", "readwritemg_8F90.html#ab6c6c3d1925977e2c4013b3da342dc37", null ],
    [ "igetmxby", "readwritemg_8F90.html#a87f1117bcbbc713c95bdca6f1bb1214c", null ],
    [ "ireadmg", "readwritemg_8F90.html#ae023a7cc381f488ac7669dc3e3ee8236", null ],
    [ "lmsg", "readwritemg_8F90.html#a44d876e69afb2688f364d8bdd0ca2400", null ],
    [ "maxout", "readwritemg_8F90.html#a1c8cdc47f69010cd4eaa20710e28f53d", null ],
    [ "msgfull", "readwritemg_8F90.html#a47d4a63b5e7276a90eee0ce83237cb60", null ],
    [ "msgini", "readwritemg_8F90.html#ae5477034329440d4127a5243305b81e4", null ],
    [ "msgwrt", "readwritemg_8F90.html#af49a08bdf36b69217da7571dcfc90624", null ],
    [ "nmsub", "readwritemg_8F90.html#a7430cdcec381d86f72a4b60a6a7db982", null ],
    [ "nmwrd", "readwritemg_8F90.html#a7c7234f006ddb78fb82844c95b608002", null ],
    [ "openmb", "readwritemg_8F90.html#a5edbefade4e7194e4dd3ee42f394034b", null ],
    [ "openmg", "readwritemg_8F90.html#a493ce59c1a2976e9714c2d9b283bdb11", null ],
    [ "padmsg", "readwritemg_8F90.html#a127f4e4664445595654494dea28d7d8f", null ],
    [ "rdmsgw", "readwritemg_8F90.html#ac23041847910e299fa2c89962597a312", null ],
    [ "readerme", "readwritemg_8F90.html#aa2a7bf49cad422b474a24edd3a1cb232", null ],
    [ "readmg", "readwritemg_8F90.html#aad947e23951efbcba54930d6f309e0a8", null ]
];