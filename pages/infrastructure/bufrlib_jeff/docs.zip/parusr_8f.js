var parusr_8f =
[
    [ "parusr", "parusr_8f.html#a8c7afcc8ef3c345d51b9e902be92f9e5", null ]
];