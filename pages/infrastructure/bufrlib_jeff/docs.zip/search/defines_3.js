var searchData=
[
  ['nemo_5fstr_5flen_1616',['NEMO_STR_LEN',['../bufrlib_8h.html#aaf134edc1efd697331c03effd4d056e0',1,'bufrlib.h']]]
];
