var searchData=
[
  ['backbufr_5fc_802',['backbufr_c',['../interfacebufrlib_1_1backbufr__c.html',1,'bufrlib']]]
];
