var searchData=
[
  ['apxdx_2ef90_865',['apxdx.F90',['../apxdx_8F90.html',1,'']]],
  ['arallocc_2ec_866',['arallocc.c',['../arallocc_8c.html',1,'']]],
  ['arallocf_2ef90_867',['arallocf.F90',['../arallocf_8F90.html',1,'']]]
];
