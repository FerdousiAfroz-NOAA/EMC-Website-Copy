var searchData=
[
  ['vers_5fstr_5flen_1618',['VERS_STR_LEN',['../bufr__interface_8h.html#a016503c090a3f1ecdac526a2e8f696b0',1,'bufr_interface.h']]]
];
