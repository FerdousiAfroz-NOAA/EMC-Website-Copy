var searchData=
[
  ['icvidx_5fc_813',['icvidx_c',['../interfacebufrlib_1_1icvidx__c.html',1,'bufrlib']]],
  ['inittbf_5fc_814',['inittbf_c',['../interfacebufrlib_1_1inittbf__c.html',1,'bufrlib']]]
];
