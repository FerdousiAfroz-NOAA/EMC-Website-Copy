var copydata_8F90 =
[
    [ "copybf", "copydata_8F90.html#a6df688983642d7845688aba3819c847e", null ],
    [ "copymg", "copydata_8F90.html#aedfe2559c1f9c59ec85c11993b378e7e", null ],
    [ "copysb", "copydata_8F90.html#a81eba6ff34f0a5020bf311ccf24d8efc", null ],
    [ "cpbfdx", "copydata_8F90.html#a352b4ac3adf31bada79d4d8672f0b800", null ],
    [ "cpymem", "copydata_8F90.html#ad102179380a6543e1ec7af4c1ba1fdde", null ],
    [ "cpyupd", "copydata_8F90.html#a9441a5be99c4a359ce4f2798037a2ea1", null ],
    [ "icopysb", "copydata_8F90.html#a31b6d67aacae28998cab9d130d39e7a2", null ],
    [ "iok2cpy", "copydata_8F90.html#a23f9925bf37d99fd855fd80cf5750ee2", null ],
    [ "mvb", "copydata_8F90.html#a4ced98b23d03cd8718d81b357ee4e2c5", null ],
    [ "ufbcpy", "copydata_8F90.html#aed892e851f07fc9bf94a2c58c809c09c", null ]
];