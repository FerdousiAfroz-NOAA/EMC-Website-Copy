var s013vals_8F90 =
[
    [ "datebf", "s013vals_8F90.html#a311f8836440703db774ee651425337b4", null ],
    [ "datelen", "s013vals_8F90.html#aadd84c217cf5fab0d94564da3f377ebe", null ],
    [ "dumpbf", "s013vals_8F90.html#ac2e40c9d462d2855dd693d9498f55342", null ],
    [ "gets1loc", "s013vals_8F90.html#a867795708832230010199b5a31f687a8", null ],
    [ "i4dy", "s013vals_8F90.html#ada4930358eb16c05c65c2df068db90c1", null ],
    [ "igetdate", "s013vals_8F90.html#aedbe120baa1a1058174325c5e2d0e487", null ],
    [ "iupbs01", "s013vals_8F90.html#a28944a4d73587a3943964a95619cb8a2", null ],
    [ "iupbs3", "s013vals_8F90.html#a6060b7b617646ee396097f20317e2f4d", null ],
    [ "iupvs01", "s013vals_8F90.html#a3b1a6e580f306826c680ff0a71d883f8", null ],
    [ "minimg", "s013vals_8F90.html#a70447e085c4523fa53796c5317f63ae8", null ],
    [ "pkbs1", "s013vals_8F90.html#a5522b3ec85470f1def91880bbc5df5e6", null ],
    [ "pkvs01", "s013vals_8F90.html#ac8fa984389323f08dd1cbd3aa6b57da9", null ],
    [ "reads3", "s013vals_8F90.html#ac96e5200de4ecc84f79caa98177e60f6", null ],
    [ "upds3", "s013vals_8F90.html#a7bf4d22f9bb27412a9d041f7a5d7bca6", null ]
];