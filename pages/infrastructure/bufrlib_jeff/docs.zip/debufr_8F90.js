var debufr_8F90 =
[
    [ "fdebufr_c", "debufr_8F90.html#abd70421a18d899bec6fbdade1262dd0b", null ],
    [ "openbt", "debufr_8F90.html#a8dbba5dc66c2e09ccdd8065dda184f89", null ],
    [ "ltbd", "debufr_8F90.html#a9cb558bc60eed8b777532f56fff8a08c", null ],
    [ "ludx", "debufr_8F90.html#a88fbe3e8e14e3810e1dc3f1560d1c51f", null ],
    [ "tbldir_f", "debufr_8F90.html#ad7e71b6c16362d8d65d97662bcdd7d02", null ]
];