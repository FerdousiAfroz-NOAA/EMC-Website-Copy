var bitmaps_8F90 =
[
    [ "gettagre", "bitmaps_8F90.html#a867a81be072effc2a9d2de0d6031e264", null ],
    [ "igetrfel", "bitmaps_8F90.html#a2dd600ba6cd71e06a19d88956337781b", null ],
    [ "imrkopr", "bitmaps_8F90.html#ad95571bf5308d6b64163d3bcc7ea3512", null ],
    [ "strbtm", "bitmaps_8F90.html#a81f55f4b1f740f3ac6e3f56ee0a06dee", null ]
];