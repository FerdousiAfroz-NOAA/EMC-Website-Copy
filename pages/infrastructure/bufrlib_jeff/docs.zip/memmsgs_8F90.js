var memmsgs_8F90 =
[
    [ "cpdxmm", "memmsgs_8F90.html#a28854648f33f49aaeb3b2209e00c0ae7", null ],
    [ "ireadmm", "memmsgs_8F90.html#afa09c66c60b22359e9642fa6eee8fcbb", null ],
    [ "rdmemm", "memmsgs_8F90.html#a379c2ad518735b00eecff6ddcf32b278", null ],
    [ "rdmems", "memmsgs_8F90.html#a2687d7372647fc32c4713c7e9eb6d268", null ],
    [ "readmm", "memmsgs_8F90.html#a6bbcaf22a939d766b7de35ff855531c5", null ],
    [ "ufbmem", "memmsgs_8F90.html#a4959c5f16b679cf4f90b2d5dcfe74247", null ],
    [ "ufbmex", "memmsgs_8F90.html#a9072ba79bf636849068780fa6467282c", null ],
    [ "ufbmms", "memmsgs_8F90.html#af0432ae9b24903a84c35bcdbbab9b0f6", null ],
    [ "ufbmns", "memmsgs_8F90.html#ab44b6a9dd950697675861504ccb24a83", null ],
    [ "ufbrms", "memmsgs_8F90.html#ae3e462b1a3f2d5af01807bdcded6a745", null ],
    [ "ufbtam", "memmsgs_8F90.html#aef5cd104e2b7ce86e852e4878c8efc9d", null ]
];