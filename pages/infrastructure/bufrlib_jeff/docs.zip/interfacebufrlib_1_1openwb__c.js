var interfacebufrlib_1_1openwb__c =
[
    [ "openwb_c", "interfacebufrlib_1_1openwb__c.html#a7859316c1cfa913d54d3fc36b619cb28", null ]
];