var cread_8c =
[
    [ "backbufr", "cread_8c.html#ad5429d7ed327f515c880227bb795162b", null ],
    [ "cewind", "cread_8c.html#afffb1b48f2c7d82abebcf2564d47438a", null ],
    [ "closfb", "cread_8c.html#a7b13da152c5a09e0fc1c92d8eb41154b", null ],
    [ "crdbufr", "cread_8c.html#a8b09f32462059d646e44ea6098a08edc", null ],
    [ "cwrbufr", "cread_8c.html#a95bc32869561911e9ca020628802edc5", null ],
    [ "openab", "cread_8c.html#a8eb759a820f7f12a3b75e92473db3c78", null ],
    [ "openrb", "cread_8c.html#ab18be8cbb2bdbdb682adce89dd1a9c69", null ],
    [ "openwb", "cread_8c.html#aa7b36dfb6c0fe0f9a1104d34c5acfa5e", null ]
];