var misc_8F90 =
[
    [ "bvers", "misc_8F90.html#a76aaeb3402158be94f735c166f93a527", null ],
    [ "capit", "misc_8F90.html#abb1e33496bab2eb5a1c93f44173f57ea", null ],
    [ "igetsc", "misc_8F90.html#a5b379fcc508f3f50fa71042b8e3645af", null ],
    [ "iokoper", "misc_8F90.html#a1bc01a10f226d09971ab1a3b0d3734bf", null ],
    [ "irev", "misc_8F90.html#a1cd5e68cc460b388986ba7273abdd689", null ],
    [ "isize", "misc_8F90.html#ac720bf9bc96336f8e4bf8120852f094e", null ],
    [ "jstnum", "misc_8F90.html#a0e7d4106a679cae0404866a8781a7651", null ],
    [ "strnum", "misc_8F90.html#a93d704d3c84005bb12c261225445a99e", null ],
    [ "strsuc", "misc_8F90.html#ab18db8197d0e5256ff5dfd2f26304d28", null ]
];