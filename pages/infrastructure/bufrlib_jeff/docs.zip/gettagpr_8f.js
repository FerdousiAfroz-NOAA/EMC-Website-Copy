var gettagpr_8f =
[
    [ "gettagpr", "gettagpr_8f.html#afa95ba65c1f04061bcc67bfc42f2591e", null ]
];