var parutg_8f =
[
    [ "parutg", "parutg_8f.html#a48496d3ac23b5e7d75a524f4ae62e181", null ]
];