var annotated_dup =
[
    [ "bufr_interface", "namespacebufr__interface.html", [
      [ "ccbfl_c", "interfacebufr__interface_1_1ccbfl__c.html", "interfacebufr__interface_1_1ccbfl__c" ],
      [ "cobfl_c", "interfacebufr__interface_1_1cobfl__c.html", "interfacebufr__interface_1_1cobfl__c" ],
      [ "crbmg_c", "interfacebufr__interface_1_1crbmg__c.html", "interfacebufr__interface_1_1crbmg__c" ],
      [ "cwbmg_c", "interfacebufr__interface_1_1cwbmg__c.html", "interfacebufr__interface_1_1cwbmg__c" ],
      [ "dlloctbf_c", "interfacebufr__interface_1_1dlloctbf__c.html", "interfacebufr__interface_1_1dlloctbf__c" ]
    ] ],
    [ "bufrlib", "namespacebufrlib.html", [
      [ "arallocc_c", "interfacebufrlib_1_1arallocc__c.html", "interfacebufrlib_1_1arallocc__c" ],
      [ "ardllocc_c", "interfacebufrlib_1_1ardllocc__c.html", "interfacebufrlib_1_1ardllocc__c" ],
      [ "backbufr_c", "interfacebufrlib_1_1backbufr__c.html", "interfacebufrlib_1_1backbufr__c" ],
      [ "cewind_c", "interfacebufrlib_1_1cewind__c.html", "interfacebufrlib_1_1cewind__c" ],
      [ "closfb_c", "interfacebufrlib_1_1closfb__c.html", "interfacebufrlib_1_1closfb__c" ],
      [ "cpmstabs_c", "interfacebufrlib_1_1cpmstabs__c.html", "interfacebufrlib_1_1cpmstabs__c" ],
      [ "crdbufr_c", "interfacebufrlib_1_1crdbufr__c.html", "interfacebufrlib_1_1crdbufr__c" ],
      [ "cwrbufr_c", "interfacebufrlib_1_1cwrbufr__c.html", "interfacebufrlib_1_1cwrbufr__c" ],
      [ "icvidx_c", "interfacebufrlib_1_1icvidx__c.html", "interfacebufrlib_1_1icvidx__c" ],
      [ "inittbf_c", "interfacebufrlib_1_1inittbf__c.html", "interfacebufrlib_1_1inittbf__c" ],
      [ "openab_c", "interfacebufrlib_1_1openab__c.html", "interfacebufrlib_1_1openab__c" ],
      [ "openrb_c", "interfacebufrlib_1_1openrb__c.html", "interfacebufrlib_1_1openrb__c" ],
      [ "openwb_c", "interfacebufrlib_1_1openwb__c.html", "interfacebufrlib_1_1openwb__c" ],
      [ "restd_c", "interfacebufrlib_1_1restd__c.html", "interfacebufrlib_1_1restd__c" ],
      [ "sorttbf_c", "interfacebufrlib_1_1sorttbf__c.html", "interfacebufrlib_1_1sorttbf__c" ],
      [ "srchtbf_c", "interfacebufrlib_1_1srchtbf__c.html", "interfacebufrlib_1_1srchtbf__c" ],
      [ "strtbfe_c", "interfacebufrlib_1_1strtbfe__c.html", "interfacebufrlib_1_1strtbfe__c" ],
      [ "stseq_c", "interfacebufrlib_1_1stseq__c.html", "interfacebufrlib_1_1stseq__c" ]
    ] ]
];