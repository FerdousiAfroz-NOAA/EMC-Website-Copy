var getabdb_8f =
[
    [ "getabdb", "getabdb_8f.html#a5a224df0ff920fff5ce7adc7a78ccf39", null ]
];