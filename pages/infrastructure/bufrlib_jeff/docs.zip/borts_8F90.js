var borts_8F90 =
[
    [ "bort", "borts_8F90.html#adc4659c5e9171f22248cf61e054ddd17", null ],
    [ "bort2", "borts_8F90.html#afef28b5a86909cc8999fad7d98b11f00", null ]
];